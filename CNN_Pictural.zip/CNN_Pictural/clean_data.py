import re
import pandas as pd
import numpy as np
import os
import shutil


'''
This script cleans data and prepare a new folder with clean dataset.

Clarification:
The images are ordered according to the  aligned.mol2 file. Therefore
we extracted ids (ZINC…) of the molecules from the aligned.mol2,
and then, looked up for the molecules' scores in the  summary_2.0.sort file.

'''

# open and read mols file
mol_file = open(os.path.join(os.getcwd(),'data', 'aligned.mol2'), 'r')
mol_contents = mol_file.read()
# print(mol_contents)

# extract mol ids from mol file
pattern = 'ZINC\d+'
mols = re.findall(pattern, mol_contents)
mols = pd.DataFrame(mols)

# open and read scores file
scores = pd.read_csv(os.path.join(os.getcwd(), 'data', 'summary_2.0.sort'), header=None)   # 919 rows
# extract mols and scores columns
scores = scores.iloc[:,[0,4]]

# extract mol ids in scores file using the same pattern
pattern = 'ZINC\d+'
for i in range(len(scores)):
    match = re.search (pattern, scores.iloc[i,0])
    scores.iloc[i,0] = match.group()

# remove from scores the mols (rows) that do not appear in mols table
rm_indices = [] # list of indices to remove
index = 0
for i in list(scores.iloc[:,0]):
    if i not in list(mols.iloc[:,0]):
        rm_indices.append(index)
    index += 1
scores = scores.drop(rm_indices)   #862 rows

# check how many duplicated mol ids in each table
# if keep=False, it consider all of the same values as duplicates
scores.duplicated(0, keep=False).sum() #71
mols.duplicated(keep=False).sum()      #68

# save duplicated mols indices in a list in order to remove in pictures
pics2remove = mols[mols.duplicated(keep = False) == True].index.to_list()

# count identical ids
mols.iloc[:,0].value_counts()
scores.iloc[:,0].value_counts()

# remove rows with duplicated mol ids
scores.drop_duplicates(0, keep=False, inplace=True)   # 791
mols.drop_duplicates(keep=False, inplace=True)        # 792

# find which of the mols doesn't exist in the (scores minus duplicated)?
for i in list(mols.iloc[:,0]):
    if i not in list(scores.iloc[:,0]):
        print('this mol is duplicated *3 in scores, therefore, will be removed: {}'.format(i))
        # ZINC06787285 (this mol is duplicated *3 in scores, however it appears only once in mols)

# extract its index, add to pics2remove list and remove from mols
idx = mols[mols.iloc[:,0]=='ZINC06787285'].index.to_list()
pics2remove.append(idx[0])
mols.drop(idx, inplace=True)  # 791

# # save pics2remove
# pd.DataFrame(pics2remove).to_csv('pics2remove.csv', header=False)
# pics2remove = np.array(pics2remove)
# np.save('pics2remove', pics2remove)

# Now the mols and the scores tables have the same mols
# merge tables according to mols table order (this is the order of the images)
merge = pd.merge(mols, scores, how='inner')
# img_names = os.listdir(os.path.join(os.getcwd(), 'data', 'orig_data'))
img_names = os.listdir(r"\data\clean_data")

# remove irrelevant image names
img_names = np.delete(img_names, list(pics2remove), axis=0)
print('number of mols after cleaning: {}'.format(len(img_names))) # (801)
# separate 10 last molecules for the test
test_names = img_names[-10:]
img_names = img_names[:-10]
# add image names column to the merge table
merge.insert(0, 'img_names', img_names)
# save the file
merge.to_csv('data\merge_file.csv', header=False, index=False)


# create clean dataset of images, copy relevant images to the new directory
# create directory
# path exists or not
clean_data_path = os.path.join(os.getcwd(), 'data', 'clean_data')
if os.path.exists(clean_data_path):
    print('''The folder {} has already exist'''.format(clean_data_path))
else:
    os.mkdir(clean_data_path)
    # create the list of original images
    orig_imgs = os.listdir(r"\data\clean_data")
    clean_imgs = img_names
    for img in orig_imgs:
        if img in clean_imgs:
            link2img = os.path.join(r"\data\clean_data", img)
            shutil.copy(link2img, clean_data_path)
print('The folder with clean data has been created. There are {} images.'.format(len(os.listdir(os.path.join(clean_data_path)))))


# create folder with final test data - 10 new molecules
final_data_path = os.path.join(os.getcwd(), 'data', 'final_test_data')
if os.path.exists(final_data_path):
    print('''The folder {} has already exist'''.format(final_data_path))
else:
    os.mkdir(final_data_path)
    # create the list of original images
    orig_imgs = os.listdir(r"\data\clean_data")
    for img in orig_imgs:
        if img in test_names:
            link2img = os.path.join(r"\data\clean_data", img)
            shutil.copy(link2img, final_data_path)
print('The folder with test data has been created. There are {} images.'.format(len(os.listdir(final_data_path))))

