from matplotlib import pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten
from tensorflow.keras.layers import Conv2D, MaxPooling2D
from tensorflow.keras.callbacks import ModelCheckpoint, CSVLogger, ReduceLROnPlateau, EarlyStopping
import os
import preprocess
from sklearn.model_selection import KFold
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.optimizers import Adam
import scipy.stats  as stats

def get_model(input_shape, learning_rate):

    model = Sequential()
    model.add(Conv2D(16, kernel_size=(3, 3), activation='relu', input_shape=input_shape, padding='same'))
    model.add(MaxPooling2D(pool_size=(3, 3), padding='same'))

    model.add(Conv2D(32, kernel_size=(3, 3), activation='relu', padding='same'))
    model.add(MaxPooling2D(pool_size=(3, 3), padding='same'))

    model.add(Flatten())
    model.add(Dense(32, activation='relu'))

    model.add(Dropout(0.2))
    model.add(Dense(1))

    model.compile(optimizer=Adam(learning_rate=learning_rate), loss='mean_absolute_error')

    return model

def create_callbacks(type):
    # create callbacks
    calls = []
    # freeze best model
    calls.append(ModelCheckpoint('training_logs/{}_model.h5'.format(type),
                                 monitor='val_loss', save_best_only=True, save_weights_only=False))
    # save training history
    calls.append(CSVLogger('training_logs/{}_log.csv'.format(type), separator=',', append=False))
    # # reduce learning rate
    # calls.append(ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=25, min_lr=0.0000001))
    # # schedule early stopping
    # calls.append(EarlyStopping(monitor='val_loss', mode='min', patience=50))

    return calls

def plot_train_logs(history_obj, type):
    # plot training progress
    # plt.plot(history_obj.history['loss'])
    # plt.plot(history_obj.history['val_loss'])
    plt.plot(history_obj['loss'])
    plt.plot(history_obj['val_loss'])
    plt.title('loss=mae')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'validation'], loc='upper right')
    plt.ylim(bottom=0, top=5)
    plt.xlim(left=0, right=1200)
    plt.show()
    plt.savefig('training_logs/{}_loss.png'.format(type))
    plt.close()

def plot_cross_logs(histories, type):
    for i in range(len(histories)):
        # plot loss
        # plt.subplot(211)
        plt.title('Loss')
        plt.plot(histories[i].history['loss'], color='blue', label='train')
        plt.plot(histories[i].history['val_loss'], color='orange', label='test')
        plt.legend(['train', 'validation'], loc='upper right')
    plt.show()
    plt.savefig('training_logs/{}_kfolds.png'.format(type))
    plt.close()

def run_cross_validation(data_path, type, factor, batch_size, epochs, n_folds, learning_rate):
    print('running cross validation...')
    data = preprocess.process(data_path, type, factor)
    # load only train examples
    X_train, y_train, _, _ = preprocess.train_test_split(data2split=data)
    losses, histories = list(), list()
    # prepare cross validation
    kfold = KFold(n_folds, shuffle=True, random_state=1)
    # enumerate splits
    for train_ix, test_ix in kfold.split(X_train):
        # define model
        model = get_model(X_train[0].shape, learning_rate)
        # select rows for train and test
        trainX, trainY, testX, testY = X_train[train_ix], y_train[train_ix], X_train[test_ix], y_train[test_ix]
        # fit model
        callbacks = create_callbacks(type)
        history = model.fit(trainX, trainY, epochs=epochs, batch_size=batch_size,
                            validation_data=(testX, testY), verbose=0, callbacks = callbacks)
        # evaluate model
        mae = model.evaluate(testX, testY, verbose=0)
        print('> %.3f' % (mae))
        # append losses
        losses.append(mae)
        # append histories
        histories.append(history)

    plot_cross_logs(histories, type)
    # print summary
    print('loss: mean=%.3f std=%.3f' % (np.mean(losses), np.std(losses)))

def fit_final_model(data_path, type, factor, batch_size, epochs, learning_rate):
    print('fitting final model...')
    data = preprocess.process(data_path, type, factor)
    # split data set
    trainX, trainY, testX, testY = preprocess.train_test_split(data2split=data)
    # define model
    model = get_model(data[0].shape, learning_rate)
    callbacks = create_callbacks(type)
    # fit model
    history = model.fit(trainX, trainY, validation_data=(testX, testY), epochs=epochs, batch_size=batch_size, callbacks= callbacks)
    plot_train_logs(history, type)

def evaluate_final_model(data_path, type, factor):
    print('evaluating final model...')
    data = preprocess.process(data_path, type, factor)
    # split dataset
    trainX, trainY, testX, testY = preprocess.train_test_split(data2split=data)
    # load model
    model = load_model('/training_logs/{}_model.h5'.format(type))
    # evaluate model on test dataset
    mae = model.evaluate(testX, testY, verbose=0)
    pred = model.predict(testX)
    pearson, p_val = stats.pearsonr(testY.reshape(-1), pred.reshape(-1))
    print("MAE" ,'> %.3f' % (mae))
    print("pearson" ,'> %.3f' % (pearson), " P-Value", '> %.3f' % (p_val))
    # # predictions
    # predictions = np.round(model.predict(testX), 2)
    # print(np.hstack([predictions, testY]).astype('float32'))

def run_final_test(data_path, type, factor):
    print('running final test...')
    data = preprocess.process(data_path, type, factor)
    # load best model
    model = load_model('training_logs/{}_model.h5'.format(type))
    # predict the class
    result = model.predict(data)
    for score in result:
        print(np.squeeze(score))

if __name__ == '__main__':


    path = os.path.join(os.getcwd(), 'data', 'clean_data', '*g')
    # path=r"\data\clean_data\*.png"
    final_path = os.path.join(os.getcwd(), 'data', 'final_test_data', '*g')
    #
    # image pre-processing parameters
    factor = 50  # size factor
    # type = 'rgb'
    # type = 'gray'
    type = 'binary'
    # # training parameters
    # n_folds=5
    # epochs = 200
    # batch_size = 1
    # learning_rate = 0.001
    #
    # # data = preprocess.process(path, type, factor)
    # model=get_model((50,50,3),learning_rate)
    # # run_cross_validation(path, type, factor, batch_size, epochs, n_folds, learning_rate)
    # fit_final_model(path, type, factor, batch_size, epochs, learning_rate)
    evaluate_final_model(path, type, factor)
    # # run_final_test(final_path, type, factor)




