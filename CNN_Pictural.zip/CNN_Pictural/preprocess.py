import pandas as pd
import numpy as np
import os, glob
import cv2
from matplotlib import pyplot as plt

'''Data pre-processing and data split scripts'''

def calc_crop(link2data):
    '''
    detects molecules in the images and returns coordinates for optimal bounding box
    '''
    min_x, min_y, max_w, max_h = 10000, 10000, 0, 0

    for link in link2data:
        link2imgs = glob.glob(link)
        for link2img in link2imgs:
            img = cv2.imread(link2img)
            # convert the image to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # convert image to binary
            thresh = cv2.threshold(gray, 225, 255, cv2.THRESH_BINARY_INV)[1]
            # enlarge mols in the images
            mask = thresh.copy()
            mask = cv2.dilate(mask, None, iterations=5)
            # detect mol
            contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            # find area
            areas = [cv2.contourArea(c) for c in contours]
            max_index = np.argmax(areas)
            # find coordinates of max area
            cnt = contours[max_index]
            x, y, w, h = cv2.boundingRect(cnt)
            im_w, im_h = x + w, y + h
            if x < min_x:
                min_x = x
            if y < min_y:
                min_y = y
            if im_w > max_w:
                max_w = im_w
            if im_h > max_h:
                max_h = im_h
    print('min_x, min_y, max_w, max_h: {}'.format((min_x, min_y, max_w, max_h)))
    return (min_x, min_y, max_w, max_h)

def show_box(x, y, im_w, im_h, im_path):
    img = cv2.imread(im_path)
    cv2.rectangle(img, (x, y), (im_w, im_h), (0, 255, 0), 2)
    cv2.imshow("Show", img)
    cv2.waitKey()
    cv2.destroyAllWindows()

def load_data(data2load):
    # load images as numpy array
    data = []
    images = glob.glob(data2load)
    for img in images:
        data.append(cv2.imread(img)) # loads an image in the array format
    data = np.array(data)
    print('data loaded: {}'.format(data.shape))  # (791, 480, 640, 3)
    return np.array(data)

def dilate_data(data2dilate, data_type):
    dilated = []
    for img in data2dilate:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(gray, 224, 255, cv2.THRESH_BINARY_INV)[1]
        if data_type =='rgb':
            bitwise = cv2.bitwise_and(img, img, mask=thresh)
            dilate = cv2.dilate(bitwise, None, iterations=5)
        elif data_type =='gray' or data_type =='grey':
                bitwise = cv2.bitwise_and(gray, gray, mask=thresh)
                dilate = cv2.dilate(bitwise, None, iterations=5)
        else:
            if data_type == 'binary':
                dilate = cv2.dilate(thresh, None, iterations=5)
        dilated.append(dilate)
    dilated = np.array(dilated)
    print('data delated: {}'.format(dilated.shape))
    return dilated

def crop_data(data2crop):
    crop = []
    for img in data2crop:
        crop.append(img[8:783, 210:985]) # min_x, min_y, max_w, max_h: 211, 126, 985, 783 >> 126:783, 211:985 >>
    crop = np.array(crop)
    print ('data cropped: {}'.format (crop.shape))
    return crop

def resize_data(data2resize, factor):
    if factor > 1:
        new_width, new_height = factor, factor
    if factor <= 1:
        width, height = data2resize[0].shape[1], data2resize[0].shape[0]
        new_width, new_height = int(factor*width), int(factor*height)
    resized_data = []
    for orig_img in data2resize:
        resized_img = cv2.resize(orig_img,(new_width, new_height))
        resized_data.append(resized_img)
    resized_data = np.array(resized_data)
    print('data resized to {}'.format(resized_data.shape))
    return resized_data

def plot_im(data2plot):
    # plot several images from the dataset
    for i in range(25):
        # define subplot
        plt.subplot(5, 5, i+1)
        # turn off axis
        plt.axis('off')
        # plot raw pixel data
        plt.imshow(data2plot[i])
    plt.show()

def scale_pixels(data2scale):
    # normalize data to [0,1]
    data = data2scale.astype('float32')
    data = data / 255.0
    print('data scaled: {}'.format(data.shape))
    return data

def convert(data2convert, data_type):
        # convert images to gray scale images
        data = np.array([cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) for image in data2convert])
        # reshape data set into 4D array
        data = data.reshape(data.shape[0], data.shape[1], 1)

        if data_type == 'grey' or data_type == 'gray':
            print('RGB images successfully converted to grayslae images.')
        else:
            if data_type == 'binary':
                # convert grayscale images to binary images
                data = np.array([cv2.threshold(image, 254, 255, cv2.THRESH_BINARY)[1] for image in data])
                print('RGB images successfully converted to binary images.')

        # reshape data set into 4D array
        data = data.reshape(data.shape[0], data.shape[1], data.shape[2], 1)
        print('Processed data shape: {}'.format(data.shape))
        return data

def train_test_split(data2split):
    print('split data...')

    '''
    We decided to perform all experiments with the same split of train and test data.
    This script loads two files with molecules ids for train and test,
    and then, prepare the data split according to these files' split
    '''
    # # split to train and test data
    # X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size = 0.2)
    # print(len(X_train), len(X_test)) # 632, 159

    train = pd.read_csv(os.path.join(os.getcwd(), 'data', 'train_test_split', 'train_data_mol_index.csv'), index_col=0, header=None)
    test = pd.read_csv(os.path.join(os.getcwd(), 'data', 'train_test_split', 'test_data_mol_index.csv'), index_col=0, header=None)
    # remove ZINC06787285 from the train data as it appears 3 times in the original dataset and was removed
    idx = train[train.iloc[:, 0] == 'ZINC06787285'].index.to_list()
    train.drop(idx, axis=0, inplace=True)
    # print('Train size: {} \nTest size: {}'.format(len(train), len(test)))  # 632, 159

    # load merge file
    merge_file = pd.read_csv(os.path.join('data','merge_file.csv'), header=None)
    split_file = merge_file
    # add train\ test column to the split file
    split_file[r'train\test'] = 0
    split_file.columns = ['img', 'id', 'score', r'train\test']
    n_samples = len(split_file)

    for i in range(n_samples):
        if split_file.loc[i, 'id'] in train.values:
            split_file.loc[i, r'train\test'] = 'train'
        else:
            if split_file.loc[i, 'id'] in test.values:
                split_file.loc[i, r'train\test'] = 'test'

    split_file.to_csv('data/train_test_split/data_split.csv')

    ''' prepare split data including X_train, X_test, y_train, y_test'''

    X_train_data = []
    y_train_data = []

    X_test_data = []
    y_test_data = []

    for idx_sample in range(n_samples):
        if split_file.loc[idx_sample, r'train\test'] == 'train':
            X_train_data.append(data2split[idx_sample])
            y_train_data.append(split_file.loc[idx_sample, 'score'])
        if split_file.loc[idx_sample, r'train\test'] == 'test':
            X_test_data.append(data2split[idx_sample])
            y_test_data.append(split_file.loc[idx_sample, 'score'])

    # convert lists to numpy arrays
    X_train_data = np.array(X_train_data)
    y_train_data = np.array(y_train_data)

    X_test_data = np.array(X_test_data)
    y_test_data = np.array(y_test_data)

    # reshape 1d arrays to 2d arrays
    y_train_data = y_train_data.reshape(len(y_train_data), 1)
    y_test_data = y_test_data.reshape(len(y_test_data), 1)

    print('train: {}, test: {}'.format(len(X_train_data), len(X_test_data)))
    return X_train_data, y_train_data, X_test_data, y_test_data

def process(path2data, data_type, factor):
    # load data
    data = load_data(path2data)
    # dilate date
    data = dilate_data(data, data_type)
    # crop data
    data = crop_data(data)
    # resize data
    data = resize_data(data, factor)
    # normalize data values to [0,1]
    data = scale_pixels(data)

    if data_type == 'gray' or data_type == 'grey' or data_type == 'binary':
        data = data.reshape(data.shape[0], data.shape[1], data.shape[2], 1)
    print('data processed in {} stage'.format(data_type))
    return data

if __name__ == '__main__':
    path = os.path.join(os.getcwd(), 'data', 'clean_data', '*g')
    final_path = os.path.join(os.getcwd(), 'data', 'final_test_data', '*g')
    # min_x, min_y, max_w, max_h = calc_crop([path,final_path])  # 211, 126, 985, 783
    data = process(path, data_type='rgb', factor=50)
    # plot several samples from data
    plot_im(data)
    # split data
    X_train, X_train, X_test, y_test = train_test_split(data)  # 632, 159

    # example for the paper
    image_path = os.path.join(os.getcwd(), 'data', 'clean_data', 'img0393.png')  # ZINC54418570
    # load data
    data = load_data(image_path)
    # dilate date
    data = dilate_data(data, 'rgb')
    # crop data
    data = crop_data(data)
    # resize data
    data = resize_data(data, 50)
    # normalize data values to [0,1]
    data = scale_pixels(data)

    image = process(image_path, data_type='rgb', factor=50)
    plt.imshow(image[0])




