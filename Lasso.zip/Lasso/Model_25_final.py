# By Lihi Gur Arie
# Model 15 Lasso
import os
import numpy as np
import pandas as pd
from pickle import load
import sys
sys.path.insert(-1, os.path.dirname(__file__))
from preproccesing import get_features_from_mol_list, Mol2MolSupplier, MolFolderSupplier
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import shap
import matplotlib.pyplot as plt
from Lasso_Regressor import  LGRF,  call_LGRS
from Features_visualization import correlation_map
import seaborn as sns
import scipy.stats  as stats


class LGRF25():

    def __init__(self, RD_features_df_to_predict = None, mol_list_to_predict=None, y_true = None):
        self.y_true = y_true
        self.X_to_predict = None
        self.dir_path = None
        self.smote = None
        self.X_train = None

        # if RD_features_df_to_predict and mol_list_to_predict:
        #     raise ValueError('Only one of "RD_features_df_to_predict" or "mol_list_to_predict" - should have value')
        if RD_features_df_to_predict is not None:
            self.X_to_predict = RD_features_df_to_predict.copy()
        if mol_list_to_predict is not None:
            # Convert mol to RDkit features:
            self.X_to_predict = get_features_from_mol_list(mol_list_to_predict)
        self.dir_path = os.path.dirname(os.path.realpath(__file__))+r'/'

    def main(self):

        # Load the chosen features list:
        features = pd.read_csv(self.dir_path+r"program_files\Features_names_model25.csv", index_col=0, header=None)
        # Take the correct features according to model_15 (44 features):
        X_to_predict_reduced = self.X_to_predict[features.iloc[:-1].squeeze()]

        # Load modal_25 parameters:
        scaler_x = load(open(self.dir_path+'program_files\Saved_scaler_x_Model25.sav', 'rb'))     # load the scaler X
        scaler_y = load(open(self.dir_path+'program_files\Saved_scaler_y_Model25.sav', 'rb'))     # load the scaler y_true
        model = load(open(self.dir_path + 'program_files\Saved_model_Model25.sav', 'rb'))  # load the model

        # Scale the new data_origin:
        X_to_predict_scaled = pd.DataFrame(scaler_x.transform(X_to_predict_reduced), index=X_to_predict_reduced.index, columns=X_to_predict_reduced.columns)

        # Predict :
        scaled_pred = model.predict(X_to_predict_scaled)
        scaled_pred = np.array(scaled_pred).reshape(-1, 1)
        predictions = pd.DataFrame(scaler_y.inverse_transform(scaled_pred), index=self.X_to_predict.index.values, columns=['Predicted_score'])

        if self.y_true is None:
            return predictions, X_to_predict_reduced
        else:
            evaluations = self.evaluate(predictions)
            return predictions, evaluations

    def evaluate(self, pred):

        MSE = mean_squared_error(self.y_true, pred)
        MAE = mean_absolute_error(self.y_true, pred)
        r2 = r2_score(self.y_true, pred)
        pearson, p_val = stats.pearsonr(self.y_true.max_affin, pred.Predicted_score)
        results = pd.Series( [MSE, MAE, r2, pearson, p_val], index=['MSE', 'MAE', 'R2', "Pearson", "Pearson P-value"])
        return results


def coefplot(x_train):
    '''
    Takes in results of OLS model and returns a plot of
    the coefficients with 95% confidence intervals.

    Removes intercept, so if uncentered will return error.
    '''
    # Create dataframe of results summary
    dir_path = os.path.dirname(os.path.realpath(__file__)) + r'/'

    model = load(open(dir_path + 'program_files\Saved_model_Model25.sav', 'rb'))  # load the model
    ind = np.argpartition(np.abs(model.coef_), -10)[-10:]
    ind = ind[np.argsort(-1 * np.abs(model.coef_[np.argpartition(np.abs(model.coef_), -10)[-10:]]))]
    pd.options.display.float_format = '{:,.2f}'.format
    coef_df = pd.DataFrame({'Coefficients': model.coef_[ind], "Variables": np.abs(model.coef_[ind])})

    # Add column names
    # coef_df.columns = ['variables',"Coefficients"]

    # Set index to variable names
    coef_df.index = x_train.columns[ind]

    # Sort values by coef ascending
    # coef_df = coef_df.sort_values(reversed())

    ### Plot Coefficients ###

    # Set sns plot style back to 'poster'
    # This will make bars wide on plot

    ar = np.arange(1, 11)
    my_cmap = plt.get_cmap("OrRd")
    rescale = lambda y: (y - np.min(y)) / (np.max(y) - np.min(y))
    # coef_df['Variables'].plot(kind='barh', figsize=(9, 7),color=my_cmap(rescale(ar)))
    coef_df['Variables'].plot(kind='barh', figsize=(9, 7), color="white", fontsize=12, edgecolor="black")
    plt.title('Coefficients', fontweight='bold', fontsize=17)
    plt.axvline(x=0, color='black')
    plt.subplots_adjust(left=.3)
    plt.rc("font", family='arial')
    plt.yticks(fontweight='bold')
    plt.xticks(fontweight='normal')
    plt.gca().invert_yaxis()
    for i, v in enumerate(coef_df['Coefficients']):
        plt.text(np.abs(v) - 0.16, i + 0.1, str('{:,.2f}'.format(v)), color='black', fontsize=12, fontweight='bold')

    return plt.show()


if __name__ == '__main__':

#######################3
    # Load the molecules:
    # molecules_for_pred = pd.read_csv(r"program_files\molecules_for_pred.csv", index_col=0)
    # molecules_for_pred = molecules_for_pred.iloc[:10]
    # molecules_for_pred1 = pd.read_csv(r"program_files\extra_ten_mols.csv", index_col=0)
    # molecules_for_pred = pd.concat([molecules_for_pred,molecules_for_pred1])
    x_train = pd.read_csv(r"program_files\train_data_model_25.csv", index_col=0)
    y_train = np.array(x_train.iloc[:, -1]).reshape((-1, 1))
    x_train = x_train.iloc[:, :-1]
    x_test = pd.read_csv(r"program_files\test_data_model_25.csv", index_col=0)
    # y_test = np.array(x_test.iloc[:, -1]).reshape((-1, 1))
    y_test = pd.DataFrame(x_test.iloc[:, -1])
    x_test = x_test.iloc[:, :-1]
    # y_train= molecules_for_pred["max_affin"]


    # Predict:
    # model=LGRF25(RD_features_df_to_predict = molecules_for_pred, y_true=None)
    # predictions_model25 = model.main()
    # predictions_model25 = LGRF25(RD_features_df_to_predict = molecules_for_pred1, y_true=None).main()
    # model.shap_plot()
    # predictions_model25 = LGRF25(RD_features_df_to_predict = x_train, y_true=y_train).main()
    predictions, evaluations = LGRF25(RD_features_df_to_predict = x_test, y_true=y_test).main()

    # dir_path = os.path.dirname(os.path.realpath(__file__)) + r'/'
    # scaler_x = load(open(dir_path + 'program_files\Saved_scaler_x_Model25.sav', 'rb'))  # load the scaler X
    # scaler_y = load(open(dir_path + 'program_files\Saved_scaler_y_Model25.sav', 'rb'))  # load the scaler y_true
    # model = load(open(dir_path + 'program_files\Saved_model_Model25.sav', 'rb'))  # load the model
    #
    # # calculate shap values
    # X_to_predict_scaled = pd.DataFrame(scaler_x.transform(x_train), index=x_train.index, columns=x_train.columns)
    # explainer = shap.Explainer(model.predict, X_to_predict_scaled)
    # shap_values = explainer(X_to_predict_scaled)
    # ind = np.argpartition(np.abs(model.coef_), -10)[-10:]
    # ind = ind[np.argsort(-1 * np.abs(model.coef_[np.argpartition(np.abs(model.coef_), -10)[-10:]]))]
    # x_train.columns[ind]
    # shapV=shap_values.values[:,ind]
    # shapVabs=shap_values.abs[:,ind]
    # shap_report=pd.DataFrame(data=np.mean(shapVabs.values,axis=0), index=x_train.columns[ind])
    ## Graphs of Shap values
    # ar=np.arange(1,11)
    # my_cmap = plt.get_cmap("OrRd")
    # rescale = lambda y: (y - np.min(y)) / (np.max(y) - np.min(y))
    # plt.figure()
    # shap.summary_plot(shapVabs, X_to_predict_scaled[x_train.columns[ind]], plot_type="bar", feature_names=X_to_predict_scaled.columns[ind], show=False, sort=True, max_display = 10, color="white", axis_color="black")
    ## shap.summary_plot(shapVabs, X_to_predict_scaled[x_train.columns[ind]], plot_type="bar", feature_names=X_to_predict_scaled.columns[ind], show=False, sort=True, max_display = 10, color=my_cmap(rescale(ar)))
    # plt.rcParams['patch.edgecolor'] = 'black'
    # plt.rcParams['patch.force_edgecolor'] = True
    # for i, v in enumerate(shap_report.sort_values(by=0).values):
    #     plt.text(np.abs(v) - 0.1, i-0.1 , str('{:,.2f}'.format(v[0])), color='black', fontsize=12, fontweight='bold')
    # plt.rc('patch', edgecolor='black')
    # plt.savefig(f"Summary_plot.png", bbox_inches='tight', dpi=600)
    # plt.show()
    # plt.rc("font", family='arial', fontsize=12)
    # plt.rc("legend", fontsize=12)

    # shap.summary_plot(shapV, X_to_predict_scaled[x_train.columns[ind]], feature_names=X_to_predict_scaled.columns[ind], show=False, sort=True, max_display = 10)

    # # Graphs correlation matrix
    # data=x_train[x_train.columns[ind]]
    data=x_train
    data["y"]=y_train
    correlation_map(data, "correlation Map", save=True)

