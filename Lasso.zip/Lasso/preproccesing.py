# -*- coding: utf-8 -*-
"""
Hadar Grimberg
1/12/2021

"""


import os
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Draw, AllChem, Descriptors
import numpy as np
from rdkit.Chem import rdDepictor
from rdkit.Chem import TemplateAlign


# from rdkit.Chem.Draw import IPythonConsole
from rdkit.ML.Descriptors import MoleculeDescriptors


def getDataMatrix(x_fname,y_fname):

    minNumAt = 100000
    maxNumAt = 0
    totalNumAt = 0
    currentNumAt = 0

    feature_file = open(x_fname, "r")
    bond_value_file = open(y_fname, 'r')

    mol_features = {}
    bond_vals = {}

    in_process = False

    mol_num = 0

    for line in feature_file:

        if 'MOLECULE' in line:
            cluster_tbl = {}

        elif 'ZINC' in line:
            mol_num += 1
            mol_name = line.rstrip()
            # print('processing ' + mol_name + ' ' + str(mol_num) + '\n')

        elif 'ATOM' in line:
            in_process = True

        elif 'BOND' in line:

            in_process = False
            features_list = extractMoleculeFeatures(cluster_tbl)
            mol_features[mol_name.strip()] = features_list

            minNumAt = min(currentNumAt, minNumAt)
            maxNumAt = max(currentNumAt, maxNumAt)
            totalNumAt += currentNumAt
            currentNumAt = 0

        elif in_process:
            processAtomLine(line, cluster_tbl)
            currentNumAt += 1

        else:
            continue

    ### Extract bond values per molecule #####

    for line in bond_value_file:

        mol_name = line.split('_')[0].strip()
        val = line.split(',')[4].strip()
        bond_vals[mol_name]=val

    ### Construct data_org frame: features + bond values ####

    for mol_name in mol_features.keys():

        features_list = mol_features[mol_name]
        val = bond_vals.get(mol_name,'NaN')
        features_list = [mol_name] + features_list + [float(val)]
        mol_features[mol_name] = features_list

 #   matr = []
 #   for feature_line in mol_features.values():
 #       vals = feature_line.split()
 #       num_vals = [float(data_to_predict) for data_to_predict in vals[1::]]
 #       row = [vals[0]] + num_vals
 #       matr.append(row)

    frame = pd.DataFrame(mol_features.values())
    frame.columns = ['NAME', 'LOC1', 'LOC1DIST', 'LOC1STD', 'LOC2', 'LOC2DIST', 'LOC2STD', 'LOC3', 'LOC3DIST', 'LOC3STD',
                     'LOC4', 'LOC4DIST', 'LOC4STD', 'LOC5', 'LOC5DIST', 'LOC5STD', 'LOC6', 'LOC6DIS',
                     'LOC6STD', 'LOC7', 'LOC7DIST', 'LOC7STD', 'LOC8', 'LOC8DIST', 'LOC8STD', 'LOC9', 'LOC9DIST', 'LOC9STD' ,'LOC10', 'LOC10DIST',
                     'LOC10STD', 'LOC11', 'LOC11DIST', 'LOC11STD','BOND']
    return frame


def Mol2MolSupplier (file=None,sanitize=True):
    scaffold = Chem.MolFromSmiles("c1csc(c2ccccc2)n1")
    rdDepictor.Compute2DCoords(scaffold)
    mols=[]
    with open(file, 'r') as f:
        print('Mol2MolSupplier Opening File')
        line =f.readline()
        while not f.tell() == os.fstat(f.fileno()).st_size:
            if line.startswith("@<TRIPOS>MOLECULE"):
                mol = []
                mol.append(line)
                line = f.readline()
                while not line.startswith("@<TRIPOS>MOLECULE"):
                    mol.append(line)
                    line = f.readline()
                    if f.tell() == os.fstat(f.fileno()).st_size:
                        mol.append(line)
                        break
                mol[-1] = mol[-1].rstrip() # removes blank line at file end
                block = ",".join(mol).replace(',','')
                m=Chem.MolFromMol2Block(block,sanitize=sanitize)
                TemplateAlign.AlignMolToTemplate2D(m, scaffold, clearConfs=True)
                mols.append(m)
    return(mols)

def molFromFile(path, files):
    mols=[]
    for i in files:
        mol = Chem.MolFromMol2File(path + i)
        scaffold = Chem.MolFromSmiles("c1csc(c2ccccc2)n1")
        rdDepictor.Compute2DCoords(scaffold)
        TemplateAlign.AlignMolToTemplate2D(mol, scaffold, clearConfs=True)
        mols.append(mol)
    return mols

def MolFolderSupplier (dir=None,sanitize=True):
    mols=[]
    for file in os.listdir(dir):
        filename = os.fsdecode(file)
        if filename.endswith(".mol"):
            m=Chem.MolFromMolFile(dir+'/'+filename)
            prop_name = m.GetProp('_Name')
            m.SetProp('_Name', prop_name + '-' + filename[8:11])
            if prop_name!= filename[-4-len(prop_name):-4]:
                print(f"Mol Name doesn't match file name {prop_name} - {filename}")
            mols.append(m)
    return mols


# Loading pre-trained model via word2vec
from mol2vec.features import mol2alt_sentence, mol2sentence, MolSentence, DfVec, sentences2vec
from gensim.models import word2vec

def number_of_atoms(atom_list, table,  mol, index):
    for i in atom_list:
        table.loc[index, f'num_of_{i}'] = len(mol.GetSubstructMatches(Chem.MolFromSmiles(i)))
        # df['num_of_{}_atoms'.format(i)] = df['mol'].apply(lambda x: len(x.GetSubstructMatches(Chem.MolFromSmiles(i))))


def get_features_from_mol_list(mol_list, mol2vec_pkl_path='mol2vec/model_300dim.pkl', names=None, get_mol2vec = False, ):
    print('get_rdkit_features_df was called')
    if get_mol2vec:
        mol2vec_model = word2vec.Word2Vec.load(mol2vec_pkl_path)
    table = pd.DataFrame()
    index = 0
    mol2vec_list = []
    mol_h2vec_list = []
    descs = []
    for mol in mol_list:
        if mol:
            mol_h = Chem.AddHs(mol)
            table.loc[index, 'Name'] = mol.GetProp('_Name')
            # table.loc[index, 'SMILES'] = Chem.MolToSmiles(mol_h)
            # table.loc[index, 'NumHeavyAtoms'] = mol_h.GetNumHeavyAtoms()
            # table.loc[index,'NumAtoms']=mol_h.GetNumAtoms()
            # table.loc[index,'tpsa'] = Descriptors.TPSA(mol_h)
            # table.loc[index,'mol_w'] = Descriptors.ExactMolWt(mol_h)
            # table.loc[index,'num_valence_electrons'] = Descriptors.NumValenceElectrons(mol_h)
            # table.loc[index,'num_heteroatoms'] = Descriptors.NumHeteroatoms(mol_h)
            number_of_atoms(['C', 'O', 'N', 'Cl'], table, mol_h, index)

            if names is None:
                names = [d[0] for d in Descriptors._descList]
            calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)

            descs.append(calc.CalcDescriptors(mol))
            if get_mol2vec:
                # Extracting embeddings to a numpy.array
                # Note that we always should mark unseen='UNK' in sentence2vec() so that model is taught how to handle unknown substructures
                mol2vec_val = DfVec(sentences2vec([MolSentence(mol2alt_sentence(mol, 1))], mol2vec_model, unseen='UNK'))
                mol2vec_list.append(mol2vec_val.vec)

                mol2vec_val2 = DfVec(sentences2vec([MolSentence(mol2alt_sentence(mol_h, 1))], mol2vec_model, unseen='UNK'))
                mol_h2vec_list.append(mol2vec_val2.vec)
            index = index + 1
    # if 'Ipc' in names and ipc_avg:
    #     names.append('Ipc')
    descs = pd.DataFrame(descs, columns=names)
    if get_mol2vec:
        mol2vec_np = np.array(mol2vec_list).squeeze()
        mol2_h_vec_np = np.array(mol_h2vec_list).squeeze()
        to_join = [descs, pd.DataFrame(mol2vec_np, columns=[f'm2v_{x}' for x in range(mol2vec_np.shape[1])]),
                   pd.DataFrame(mol2_h_vec_np, columns=[f'm2v_h_{x}' for x in range(mol2_h_vec_np.shape[1])])]
    else:
        to_join = [descs]

    result = table.join(to_join)
    # result = pd.DataFrame(np.column_stack([table, mol2vec_np])) #, mol2_h_vec_np]))

    result = result.set_index('Name')
    return result

def get_data(old_data_path=None,new_data_path=None):
    if new_data_path:
        table = get_rdkit_features_df(new_data_path+'/new_subsets.mol2')
        # print(table)
        print('reading scores file')
        scores = pd.read_csv(new_data_path+r'\new_subsets.csv')
        scores = scores.set_index('ID_ZINC')
        print('removing duplicates table')
        table_dup = table.loc[table.index.duplicated(keep=False)]
        table = table.loc[~table.index.duplicated(keep=False)]
        print('removing duplicates scores')
        scores_original = scores.copy()
        scores = scores.loc[~scores.index.duplicated(keep=False)]

        table['sc1'] = 0
        table['sc2'] = 1
        merged_data = pd.concat([table, scores.loc[:, 'max_affin']], axis=1,
                                join='inner')  # merge original and new feutures
        merged_data = merged_data.loc[~merged_data.index.duplicated(keep=False)]  # remove all duplicated molecules
        print(merged_data.isnull().sum().sum())  # check if there are nulls

        new_merged = merged_data

    #############################   merge features  #################################################################
    if old_data_path:
        another_ds = get_rdkit_features_df(old_data_path)
        # another_ds = get_rdkit_features_df(old_data_path+'/aligned.mol2')

        # Data handeling:
        data = getDataMatrix(old_data_path+r"\aligned.mol2", old_data_path+r"\summary_2.0.sort")  # Get original features
        data = data.set_index('NAME')  # Set the index to molecule serial number
        another_ds['sc1'] = 1
        another_ds['sc2'] = 0
        merged_data2 = pd.concat([another_ds, data.iloc[:, -1]], axis=1, join='inner')  # merge original and new feutures
        merged_data2 = merged_data2.loc[~merged_data2.index.duplicated(keep=False)]  # remove all duplicated molecules

        merged_data2.columns = pd.Series(another_ds.columns).append(pd.Series(['max_affin']))
        new_merged = merged_data2
    # merged_data['scalfold1'] = 1
    # merged_data2['scalfold1'] = 0
    # merged_data['scalfold2'] = 0
    # merged_data['scalfold2'] = 1

    # new_merged = merged_data.append(merged_data2)
    if old_data_path and new_data_path:
        new_merged = merged_data.append(merged_data2)
        new_merged = new_merged.loc[~new_merged.index.duplicated(keep=False)]  # remove all duplicated molecules
        new_merged = new_merged.dropna()  # drop na
    return new_merged



    #print(f'new merged shape {new_merged.shape}')

# no_none=[mol for mol in mol_list if mol] # None element can´t be drawn, this loop keep only valid entries
# [Chem.SanitizeMol(mol) for mol in no_none]
# img = Draw.MolsToGridImage(no_none,molsPerRow=7,subImgSize=(150,150),legends=[mol.GetProp('_Name') for mol in no_none])
# img.show()

#
# # AddHs function adds H atoms to a MOL (as Hs in SMILES are usualy ignored)
# # GetNumAtoms() method returns a general nubmer of all atoms in a molecule
# # GetNumHeavyAtoms() method returns a nubmer of all atoms in a molecule with molecular weight > 1
#
#
# df['mol'] = df['mol'].apply(lambda x: Chem.AddHs(x))
# df['num_of_atoms'] = df['mol'].apply(lambda x: x.GetNumAtoms())
# df['num_of_heavy_atoms'] = df['mol'].apply(lambda x: x.GetNumHeavyAtoms())
# ====================
# The next obvious step is to count numbers of the most common atoms.
# # First we need to settle the pattern.
# c_patt = Chem.MolFromSmiles('C')
#
# # Now let's implement GetSubstructMatches() method
# print(df['mol'][0].GetSubstructMatches(c_patt))
# =========================================
# #We're going to settle the function that searches patterns and use it for a list of most common atoms only
# def number_of_atoms(atom_list, df):
#     for i in atom_list:
#         df['num_of_{}_atoms'.format(i)] = df['mol'].apply(lambda x: len(x.GetSubstructMatches(Chem.MolFromSmiles(i))))
#
# number_of_atoms(['C','O', 'N', 'Cl'], df)
path=""
data=get_rdkit_features_df(path+ r"\Data\newmols.mol2")
files=["\zinc_22812775.mol2", "\VS-28.mol2"]
mols=molFromFile(path,files)
mols=get_features_from_mol_list(mols)
data = pd.concat([data,mols])
