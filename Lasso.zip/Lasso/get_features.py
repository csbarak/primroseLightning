# -*- coding: utf-8 -*-
"""
Hadar Grimberg
5/24/2021

"""

import os
from rdkit import Chem
import pandas as pd
from rdkit.Chem import rdDepictor
from rdkit.Chem import TemplateAlign
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors


def Mol2MolSupplier (file=None,sanitize=True):
    scaffold = Chem.MolFromSmiles("c1csc(c2ccccc2)n1")
    rdDepictor.Compute2DCoords(scaffold)
    mols=[]
    with open(file, 'r') as f:
        print('Mol2MolSupplier Opening File')
        line =f.readline()
        while not f.tell() == os.fstat(f.fileno()).st_size:
            if line.startswith("@<TRIPOS>MOLECULE"):
                mol = []
                mol.append(line)
                line = f.readline()
                while not line.startswith("@<TRIPOS>MOLECULE"):
                    mol.append(line)
                    line = f.readline()
                    if f.tell() == os.fstat(f.fileno()).st_size:
                        mol.append(line)
                        break
                mol[-1] = mol[-1].rstrip() # removes blank line at file end
                block = ",".join(mol).replace(',','')
                m=Chem.MolFromMol2Block(block,sanitize=sanitize)
                TemplateAlign.AlignMolToTemplate2D(m, scaffold, clearConfs=True)
                mols.append(m)
    return(mols)

def get_rdkit_features_df(filePath ='data_origin/new_subsets.mol2', names=None):

    if filePath.split('.')[-1] == 'sdf':
        database = Chem.SDMolSupplier(filePath,sanitize=True)
    else:
        database = Mol2MolSupplier(filePath,sanitize=True)

    result = get_features_from_mol_list(database, names)

    return result

def number_of_atoms(atom_list, table,  mol, index):
    for i in atom_list:
        table.loc[index, f'num_of_{i}'] = len(mol.GetSubstructMatches(Chem.MolFromSmiles(i)))
        # df['num_of_{}_atoms'.format(i)] = df['mol'].apply(lambda x: len(x.GetSubstructMatches(Chem.MolFromSmiles(i))))

def get_features_from_mol_list(mol_list, names=None, ):
    print('get_rdkit_features_df was called')
    table = pd.DataFrame()
    index = 0
    descs = []
    for mol in mol_list:
        if mol:
            mol_h = Chem.AddHs(mol)
            table.loc[index, 'Name'] = mol.GetProp('_Name')
            # table.loc[index, 'SMILES'] = Chem.MolToSmiles(mol_h)
            # table.loc[index, 'NumHeavyAtoms'] = mol_h.GetNumHeavyAtoms()
            # table.loc[index,'NumAtoms']=mol_h.GetNumAtoms()
            # table.loc[index,'tpsa'] = Descriptors.TPSA(mol_h)
            # table.loc[index,'mol_w'] = Descriptors.ExactMolWt(mol_h)
            # table.loc[index,'num_valence_electrons'] = Descriptors.NumValenceElectrons(mol_h)
            # table.loc[index,'num_heteroatoms'] = Descriptors.NumHeteroatoms(mol_h)
            number_of_atoms(['C', 'O', 'N', 'Cl'], table, mol_h, index)

            if names is None:
                names = [d[0] for d in Descriptors._descList]
            calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)

            descs.append(calc.CalcDescriptors(mol))
            index = index + 1
    # if 'Ipc' in names and ipc_avg:
    #     names.append('Ipc')
    descs = pd.DataFrame(descs, columns=names)
    to_join = [descs]

    result = table.join(to_join)

    result = result.set_index('Name')
    return result