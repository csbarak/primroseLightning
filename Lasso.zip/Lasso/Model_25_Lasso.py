# by Lihi Gur-Arie
# This model25 will try to reduce further features from model 24

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys
from Lasso_Regressor import LGRF,  call_LGRS
#from Feature_reduction import  backward_features_reduction,remove_features_by_name, step_forward_feature_selection, reduce_features_by_lasso_coefficient, Remove_features_by_correlation
from sklearn.preprocessing import MinMaxScaler, StandardScaler, PowerTransformer
from termcolor import colored
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.linear_model import LinearRegression
from tqdm import tqdm
import shap
from Features_visualization import data_vs_mol_plots, splited_violin_plot, train_vs_test, correlation_map, d3_scatter_plot, d2_scatter_plot
# import pandas_profiling as pp

# Open data_origin:
# train_data_m24 = pd.read_csv(r"\program_files\train_data_model_24.csv",index_col=0)
# final_test_RD_Data = pd.read_csv(r"\program_files\sc1_old_data_test_rd_features.csv",index_col=0)
# test_data_m24 = final_test_RD_Data[train_data_m24.columns.values.squeeze()]
#
# train_data_mol_index = pd.Series(train_data_m24.index.values)
# test_data_mol_index = pd.Series(test_data_m24.index.values)
#
# train_data_mol_index.to_csv(r'train_data_mol_index.csv')
# test_data_mol_index.to_csv(r'test_data_mol_index.csv')


#MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data_m24, final_test_data= test_data_m24,alpha=0, scaler ='Standard', show_plots=True)

# Standard scale the data:
# scalar = StandardScaler().fit(train_data_m24)
# train_data_m24_standard = pd.DataFrame(scalar.transform(train_data_m24), index=train_data_m24.index, columns=train_data_m24.columns)
# test_data_m24_standard = pd.DataFrame(scalar.transform(test_data_m24), index=test_data_m24.index, columns=test_data_m24.columns)

# # Plots:
# high_residuals_mol = pd.DataFrame(train_data_r4_standard, index=['ZINC65533891','ZINC78975305'])
#high_residuals_mol = test_data_m24_standard.loc[['ZINC65533891','ZINC78975305'],:]

# data_vs_mol_plots (title = 'Model24 Box plot' , first_data = train_data_m24_standard, first_plot_type ="boxplot", second_data = high_residuals_mol, second_plot_type ='swarmplot', save = True)
#data_vs_mol_plots (title = 'Model24 swarmplot' , first_data = train_data_m24_standard, first_plot_type ="swarmplot", second_data = high_residuals_mol, second_plot_type ='swarmplot', save = True)
#train_vs_test(title = 'Model24',  train_data=train_data_m24_standard, test_data=test_data_m24_standard, plot_type = "boxplot",save = True)

# train_data, test_data,MSE_all_features = remove_features_by_name(train_data_m24, test_data_m24, [], alpha=0,scaler='Standard')
# train_data, test_data,MSE_SMR_VSA3_less = remove_features_by_name(train_data_m24, test_data_m24, ['SMR_VSA3'], alpha=0,scaler='Standard')
# train_data, test_data,MSE_SlogP_VSA8_less = remove_features_by_name(train_data_m24, test_data_m24, ['SlogP_VSA8'], alpha=0,scaler='Standard')
# train_data, test_data,MSE_PEOE_VSA12_less = remove_features_by_name(train_data_m24, test_data_m24, ['PEOE_VSA12'], alpha=0,scaler='Standard')
# train_data, test_data,MSE_PEOE_VSA5_less = remove_features_by_name(train_data_m24, test_data_m24, ['VSA_EState5'], alpha=0,scaler='Standard')
# train_data, test_data,MSE_TPSA_less = remove_features_by_name(train_data_m24, test_data_m24, ['TPSA'], alpha=0,scaler='Standard')
# train_data_m25_r1, test_data_m25_r1, MSE_PEOEVSA12_SMRVSA3_less = remove_features_by_name(train_data_m24, test_data_m24, ['PEOE_VSA12', 'SMR_VSA3'], alpha=0,scaler='Standard')
#MSE_PEOEVSA12_SMRVSA3_TPSA_less = remove_features_by_name(train_data_m24, test_data_m24, ['PEOE_VSA12', 'SMR_VSA3','TPSA'], alpha=0,scaler='Standard')
#MSE_PEOEVSA12_SMRVSA3_VSAEState5_less = remove_features_by_name(train_data_m24, test_data_m24, ['PEOE_VSA12', 'SMR_VSA3','VSA_EState5'], alpha=0,scaler='Standard')
# MSE_PEOEVSA12_SMRVSA3_SlogPVSA8_less = remove_features_by_name(train_data_m24, test_data_m24, ['PEOE_VSA12', 'SMR_VSA3','SlogP_VSA8'], alpha=0,scaler='Standard')

# train_data_m25_r1, test_data_m25_r1, MSE_PEOEVSA12_SMRVSA3_less = remove_features_by_name(train_data_m24, test_data_m24, ['PEOE_VSA12', 'SMR_VSA3'], alpha=0,scaler='Standard')
# train_data_m25_r2, full_results_table_m25_r2, selected_features_table_m25_r2, best_features_m25_r2=step_forward_feature_selection(data = train_data_m25_r1).main()
# train_data_m25_r3, best_features_m25_r3, results_table_valid_m25_r3, results_table_train_m25_r3, coefficiant_abs_median_m25_r3 = reduce_features_by_lasso_coefficient (train_data_m25_r2)
# train_data_m25_r4, results_valid_m25_r4 = backward_features_reduction(train_data_m25_r3)
# test_data_m25_r4 = final_test_RD_Data[train_data_m25_r4.columns.values.squeeze()]
# ############ SAVE ###########################################
#
# train_data_m25_r4.to_csv(r'train_data_model_25.csv')
# test_data_m25_r4.to_csv(r'test_data_model_25.csv')

########## Data visualization   ###########################

# scalar = StandardScaler().fit(train_data_m25_r4)
# train_data_m25_standard = pd.DataFrame(scalar.transform(train_data_m25_r4), index=train_data_m25_r4.index, columns=train_data_m25_r4.columns)
# test_data_m25_standard = pd.DataFrame(scalar.transform(test_data_m25_r4), index=test_data_m25_r4.index, columns=test_data_m25_r4.columns)
#
# data_vs_mol_plots (title = 'Train Model25 swarmplot' , first_data = train_data_m25_standard, first_plot_type ="swarmplot", second_data = None, second_plot_type ='swarmplot', save = True)
# data_vs_mol_plots (title = 'Train Model25 boxplot' , first_data = train_data_m25_standard, first_plot_type ="boxplot", second_data = None, second_plot_type ='swarmplot', save = True)
# train_vs_test(title = 'Model25',  train_data=train_data_m25_standard, test_data=test_data_m25_standard, plot_type = "boxplot",save = True)
##########################################################

# Open Data:
train_data = pd.read_csv(r"program_files/train_data_model_25.csv", index_col=0)
test_data = pd.read_csv(r"program_files/test_data_model_25.csv", index_col=0)


# # # ####################################################################
# #
# Tune hyperparameters:

results_table_train = pd.DataFrame()
results_table_valid = pd.DataFrame()
#
# smote_list = [False,True]
# for smote in smote_list:
#     print(f'smote = {smote}')
#     MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data, alpha=0.1, scaler ='min_max',scale_by = (-0,200),smote = smote,  save_plots=False, show_plots=False)
#     results_table_train = results_table_train.append(pd.Series(MSEs_train, name=f'Train,model22, min_max (0,200), a=0.1, smote = {smote}'))
#     results_table_valid = results_table_valid.append(pd.Series(MSEs_valid, name=f'Train,model22, min_max (0,200), a=0.1, smote = {smote}'))
#
#
# # Test results:
# smote_list = [False,True]
# for smote in smote_list:
#     print(f'smote = {smote}')
#     MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data, final_test_data=test_data, alpha=0.1, scaler ='min_max',scale_by = (-0,200),smote = smote,  save_plots=False, show_plots=False)
#     results_table_train = results_table_train.append(pd.Series(MSEs_train, name=f'TEST, model25, min_max (0,200), a=0.1, smote = {smote}'))
#     results_table_valid = results_table_valid.append(pd.Series(MSEs_valid, name=f'TEST, model25, min_max (0,200), a=0.1, smote = {smote}'))
#
# smote_list = [False, True]
# for smote in smote_list:
#     print(f'smote = {smote}')
#     MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data, alpha=0, scaler='Standard',smote=smote, save_plots=False, show_plots=False)
#     results_table_train = results_table_train.append(
#         pd.Series(MSEs_train, name=f'Train, model25, Standard, a=0, smote = {smote}'))
#     results_table_valid = results_table_valid.append(
#         pd.Series(MSEs_valid, name=f'Train,model25, Standard, a=0, smote = {smote}'))

#Test results:
# smote_list = [False]
#
# for smote in smote_list:
#     print(f'smote = {smote}')
#     # MSEs_train, MSEs_valid = call_LGRS(data=train_data, title = 'Bagging',bagging =True, final_test_data=test_data, alpha=0, scaler='Standard',  smote=smote,  save_plots=False, show_plots=True)
#     # results_table_train = results_table_train.append( pd.Series(MSEs_train, name=f'TEST bagging, model25, Standard, a=0, smote = {smote}'))
#     # results_table_valid = results_table_valid.append( pd.Series(MSEs_valid, name=f'TEST bagging, model25, Standard, a=0, smote = {smote}'))
#
#     # MSEs_train, MSEs_valid, coeff= call_LGRS(data=train_data, title = 'Lasso',   alpha=0, scaler='Standard',  smote=smote,  save_plots=False, show_plots=True)
#     # results_table_train = results_table_train.append( pd.Series(MSEs_train, name=f'lasso, Standard, a=0, smote = {smote}'))
#     # results_table_valid = results_table_valid.append( pd.Series(MSEs_valid, name=f'lasso, Standard, a=0, smote = {smote}'))
#
#     MSEs_train, MSEs_valid, coeff= call_LGRS(data=train_data, title = 'Lasso',  final_test_data=test_data, alpha=0, scaler='Standard',  smote=smote,  save_plots=False, show_plots=True)
#     results_table_train = results_table_train.append( pd.Series(MSEs_train, name=f'TEST lasso, Standard, a=0, smote = {smote}'))
#     results_table_valid = results_table_valid.append( pd.Series(MSEs_valid, name=f'TEST lasso, Standard, a=0, smote = {smote}'))
#
# # results_table_train.to_excel('results_table_train_model25_11_8_20.xlsx')
# # results_table_valid.to_excel('results_table_valid_model25_11_8_20.xlsx')
# ###############################################################################

# MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data, title = 'Train', alpha=0, scaler='Standard', save_plots=False, show_plots=False)
# results_table_train = results_table_train.append( pd.Series(MSEs_train, name=f'Train, model25, Standard, a=0'))
# results_table_valid = results_table_valid.append(pd.Series(MSEs_valid, name=f'Train, model25, Standard, a=0'))
#
MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data, title = '29_10_test_data_50', final_test_data=test_data, alpha=0, scaler='Standard', save_plots=True, show_plots=True)
results_table_train = results_table_train.append( pd.Series(MSEs_train, name=f'Test, model25, Standard, a=0'))
results_table_valid = results_table_valid.append(pd.Series(MSEs_valid, name=f'Test, model25, Standard, a=0'))
#
#
# model25 = LGRF(train_data, random_state=1, final_test_data=test_data)
# MSEs_train, MSEs_valid, coefficients = model25.main(title="Model_25_Test", alpha=0, scaler='Standard',scale_by = (-100,100),CV_Kfolds=10,smote=False,show_plots=True, save_plots=False)
# results_table_train = results_table_train.append( pd.Series(MSEs_train, name=f'Test, model25, Standard, a=0'))
# results_table_valid = results_table_valid.append(pd.Series(MSEs_valid, name=f'Test, model25, Standard, a=0'))
# model25.save_model(file_name="Model25")
