# by Lihi Gur-Arie


from Lasso_Regressor import  LGRF,  call_LGRS
from sklearn.preprocessing import FunctionTransformer
from sklearn.preprocessing import MinMaxScaler, StandardScaler, PowerTransformer
import numpy as np
import pandas as pd
from sklearn.linear_model import  Lasso, Ridge
from termcolor import colored
from sklearn.feature_selection import RFE
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.model_selection import StratifiedKFold, KFold, LeaveOneOut
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.feature_selection import VarianceThreshold
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from imblearn.over_sampling import SMOTE
from sklearn.decomposition import PCA
import inspect
import statsmodels.formula.api as sm
from sklearn.feature_selection import f_regression, mutual_info_regression
import seaborn as sns
from openpyxl import Workbook
import pickle
from tqdm import tqdm
import shap

########## Feature selection by correlation ##############################################################

class Remove_features_by_correlation:

    def __init__(self, data):  # reduce_features_by_correlation
        self.data = data.copy()
        self.var_threshold = None
        self.y_cor_threshold = None
        self.x_cor_threshold = None
        print(f'The initial number of features is {data.shape[1] - 1}')

    def main(self, var_threshold, y_cor_threshold, x_cor_threshold):
        self.var_threshold = var_threshold
        self.y_cor_threshold = y_cor_threshold
        self.x_cor_threshold = x_cor_threshold

        # Remove features with zero variance:
        selector = VarianceThreshold(var_threshold)
        selector.fit(self.data)
        train_data = self.data.loc[:, selector.get_support()]
        print(f'Low variance features were removed. New number of features = {train_data.shape[1] - 1}')

        # Remove features with low correlation to y:
        correlation_map_abs = abs(train_data.corr())  # Create a correlation map Using Pearson Correlation
        correlation_to_Y = correlation_map_abs.iloc[:, -1]  # Correlation with y_true
        train_data = train_data[correlation_to_Y.index[correlation_to_Y >= y_cor_threshold]]  # Selecting highly correlated features to y_true in the train data
        print(f'Features that are not correlated to y_true were reduced. New feature Number = {train_data.shape[1] - 1}')

        # Remove features with high corelation to each other (features that are highly dependent)
        correlation_map_abs = abs(train_data.corr())  # update correlation map after features reduction
        correlation_to_Y = correlation_map_abs.iloc[:, -1]  # update correlation to y_true after features reduction

        index_to_remove = []
        for i in correlation_map_abs.index:  # for each i:
            correlation_list = correlation_map_abs.loc[i]  # Create a correlation list
            correlation_list.loc[i] = 0  # change the correlation of a i to itself to 0 insted of 1
            correlation_list = correlation_list.iloc[:-1]  # remove y

            # Selecting highly correlated features in the train data
            collinear_index_list = correlation_list.index[
                correlation_list >= x_cor_threshold]  # Get a list of index above or equal to correlation threshold

            if len(collinear_index_list) > 0:  # if there are any features above or equal to threshold:
                # print(correlation_list.loc[collinear_index_list])

                # Remove one of the two collinear features. Remove the one with the better correlation to y
                for j in collinear_index_list:  # for each of the collinear features, leave the one with the better y correlation
                    if correlation_to_Y.loc[j] > correlation_to_Y.loc[i]:
                        index_to_remove.append(i)
                    else:
                        index_to_remove.append(j)

        index_to_remove = list(set([x for x in index_to_remove if x in train_data.columns]))

        train_data = train_data.drop(index_to_remove, axis=1)

        # f_test, pval = f_regression(train_data.iloc[:,:-1], train_data.iloc[:,-1])

        print(f'Features that are highly correlated to each other were reduced. New feature Number = {train_data.shape[1]}')
        ######################3
        # correlation_map_abs = train_data.corr()                 # update correlation map after features reduction
        # correlation_to_Y = correlation_map_abs.iloc[:, -1]      # update correlation to y_true after features reduction
        # correlation_to_Y.to_excel("Hit_map_model5.xlsx")        # Save to excel
        #######################3
        return train_data

####################################################################

class forward_features_selection:

    def __init__(self, data):
        self.data = data.copy()

    def main(self):
        # Select the best features:
        full_results_table, selected_features_table = self.reduce_features()

        # Save the relevant features:

        mse = selected_features_table['MSE']
        mse = mse.to_numpy(dtype=None, copy=False)
        # bad_features = results_table_valid.index[:np.argmin(mse) + 1]

        best_features = pd.Series(selected_features_table.index[:np.argmin(mse) + 1])
        best_features[len(best_features)] = 'max_affin'         # Add 'max_affin' (y_true) to the features list

        print(f'Number of features before reduction = {self.data.shape[1]-1}')
        # Remove irrelevant features:
        train_data = self.data[best_features]
        print(f'Number of features after reduction = {train_data.shape[1]-1}')

        return train_data, full_results_table, selected_features_table, best_features

    def reduce_features(self):
        full_results_table = pd.DataFrame()
        selected_features_table = pd.DataFrame()

        counter = 1
        features_left_names = self.data.columns[:-1]

        for i in tqdm(range (self.data.shape[1] - 1)):

            all_results, new_feature = self.scan_features(selected_features_names = selected_features_table.index.array, counter=counter, features_left_names = features_left_names)
            all_results['Round'] = counter
            # Append the i with the best mse score:
            selected_features_table = selected_features_table.append(new_feature)
            full_results_table = full_results_table.append(all_results)
            # Remove features that are already chosen:
            features_left_names = features_left_names.drop(selected_features_table.index[-1])     # Append the i with the best Adj_r2 score
            counter += 1
        return full_results_table, selected_features_table

    def scan_features(self, selected_features_names, counter, features_left_names):
        results_table_train = pd.DataFrame()
        results_table_valid = pd.DataFrame()
        i=0
        for j in features_left_names:
            if i%20==0:
                print('i-',i,'c-' ,counter,'j-', j)
            i+=1
            if counter == 1:
                current_data = self.data[[ j, 'max_affin']]
            else:
                idx = np.concatenate((selected_features_names, j, 'max_affin'), axis=None)
                current_data = self.data[idx]

            model = LGRF(current_data,  random_state=1)
            results_train, results_valid, coefficiants = model.main(title=f'model', scale_by=(-100, 100), CV_Kfolds=10, alpha=0.6, scaler='min_max',  smote=False,  save_plots=False)
            #results_train.name = '-'.join(np.concatenate((selected_features_names, j), axis=None))
            results_valid.name = j
            results_table_train = results_table_train.append(pd.DataFrame(results_train).T)
            results_table_valid = results_table_valid.append(pd.DataFrame(results_valid).T)

        best_feature_index = np.argmin(results_table_valid['MSE'])                      # The index of the i with the best mse
        best_feature_results = (results_table_valid.loc[best_feature_index])           # Get the results of the best i
        best_feature_results = best_feature_results.rename (best_feature_index)     # Give Name to the i
        print (f'Best feature is {best_feature_results.name}')
        return results_table_valid, best_feature_results

###############################################################################################3

def reduce_features_by_lasso_coefficient (train_data):
    print(f'Number of features is {train_data.shape[1] - 1}')

    results_table_train = pd.DataFrame()
    results_table_valid = pd.DataFrame()
    coefficiant_abs_median = pd.DataFrame()

    feature_names = train_data.columns.values
    last_reduced_feature = 'All_features'

    for i in range (train_data.shape[1] - 1):

        print(f'{len(feature_names)-1} Features')

        data_origin = train_data.copy().loc[:, feature_names]

        # Get the coefficients with default parameters:
        MSEs_train, MSEs_valid, coefficients = call_LGRS(data=data_origin, alpha=0.2, smote=False)
        results_table_train = results_table_train.append(pd.Series(MSEs_train, name=last_reduced_feature))
        results_table_valid = results_table_valid.append(pd.Series(MSEs_valid, name=last_reduced_feature))
        coefficiant_abs_median = coefficiant_abs_median.append(pd.Series(coefficients['abs_coef_median'], name=last_reduced_feature))

        # Reduce the feature with the lowest coeff:
        feature_names = coefficients.index.values[:-1]                # Remove the worst feature
        last_reduced_feature = coefficients.index.values[-1]          # Update the name of the feature reduced
        feature_names = np.append(feature_names, 'max_affin')         # Add the y_true back

    feature_names = train_data.columns.values
    mse = results_table_valid['MSE']
    mse = mse.to_numpy(dtype=None, copy=False)
    bad_features = results_table_valid.index[:np.argmin(mse)+1]
    best_features = pd.Series([x for x in feature_names if x not in bad_features])

    # Trim the unselected features:
    train_data_new = train_data[best_features.squeeze()]


    # # Save the results to files:
    # best_features.to_csv('Best_features_names_model17_27_7_20.csv')
    # results_table_train.to_excel("Train_feature_selection_by_coefficients_results_27_7_20.xlsx")
    # results_table_valid.to_excel("Valid_feature_selection_by_coefficients_results_27_7_20.xlsx")
    # results_table_valid.to_csv('Valid_feature_selection_by_coefficients_results_27_7_20.csv')
    # coefficiant_abs_median.to_excel(f"Median_cv_coefficiants_for_Feature_selection_by_coefficients_results_27_7_20.xlsx")

    return train_data_new, best_features, results_table_valid, results_table_train, coefficiant_abs_median

###########################################################################

def backward_log_transform (train_data):

    ######  Generate a log transformed train_data  #####

    log_transformer = FunctionTransformer(np.log1p)

    train_data_log = pd.DataFrame()
    # train_data_inv = train_data.copy()
    # train_data_sqr_root = train_data.copy()

    skewed = train_data.skew()

    # Create new train data with log transformation:
    for i in train_data.columns.values:
        if skewed.loc[i] > 0.5:
            if train_data.loc[:,i].min()>= 0:
                train_data_log.loc[:,i] = log_transformer.transform(train_data.loc[:,i].copy())

    # run over all features

    selected_results = pd.Series(name='MSE')

    features_list = pd.Series(train_data_log.columns.values[:-1], index=train_data_log.columns.values[:-1])
    remaining_features = features_list.copy()
    transformed_data = train_data.copy()

    for j in range (len(features_list)):
        print(j)
        ####  Change suspected features to log and see MSE improvement. Choose the best feature   ###
        MSE_log = pd.Series(index=features_list)

        current_data = transformed_data.copy()

        for feature in remaining_features:
            current_data [feature] = train_data_log[feature]
            model = LGRF(data=current_data)
            MSEs_train, MSEs_valid, coefficients_no_smote = model.main(title = 'model15', scaler='Standard',alpha=1e-05, scale_by=(-100,100), CV_Kfolds = 10,smote=False, save_plots=False, show_plots=False)
            MSEs_valid.name = feature
            MSE_log[feature] = MSEs_valid.MSE

        results_valid = pd.DataFrame()
        results_valid['MSE_log'] = MSE_log

        transformations_list = pd.Series(index = features_list)
        selected_results[MSE_log.idxmin()] = MSE_log[MSE_log.idxmin()]
        remaining_features = remaining_features.drop(MSE_log.idxmin())
        transformed_data [MSE_log.idxmin()] = train_data_log[MSE_log.idxmin()]

    return selected_results

####################################################################################

def remove_features_by_name(train_data, test_data, features, alpha=1e-05,scaler='Standard'):
    # This function reduce features by feature's name, and return the new MSE score
    # features as list ['feature'] form

    if len(features)> 0:
        train_data = train_data.copy().drop(features, axis=1)
        test_data = test_data.copy().drop(features, axis=1)

    MSEs_train, MSEs_valid, coefficients = call_LGRS(data=train_data, alpha=alpha, scaler=scaler, smote=False, save_plots=False, show_plots=False)
    MSEs_train_test, MSEs_test, coefficients_test = call_LGRS(data=train_data, final_test_data=test_data, alpha=1e-05, scaler='Standard', smote=False, save_plots=False, show_plots=False)
    mse_results = pd.Series()
    mse_results['MSE_train'] = MSEs_valid['MSE']
    mse_results['MSE_test'] = MSEs_test['MSE']

    return train_data, test_data, mse_results

#######################################################################################

def backward_features_reduction(data):

    results_valid = pd.DataFrame()

    MSEs_train, MSEs_valid, coefficients = call_LGRS(data=data, alpha=0.6, scaler='min_max',scale_by=(-100, 100))
    results_valid = results_valid.append(pd.Series(MSEs_valid, name='All_features'))
    ##################################################
    def remove_each_feature (data):
        backward_results_train = pd.DataFrame()
        backward_results_valid = pd.DataFrame()

        for feature in range(data.shape[1]-1):
            current_data = data.copy().drop(data.columns.values[feature], axis=1)
            features_name = data.columns.values[feature]

            MSEs_train, MSEs_valid, coefficients = call_LGRS(data=current_data, alpha=0.6, scaler ='min_max', scale_by = (-100,100))
            backward_results_valid = backward_results_valid.append(pd.Series(MSEs_valid, name=features_name))

        feature_to_remove = backward_results_valid.MSE.idxmin()
        new_data = data.copy().drop(feature_to_remove, axis=1)
        return new_data, backward_results_valid.loc[feature_to_remove]

    curr_data = data.copy()
    for j in  tqdm (range (data.shape[1]-2)):
        print (j)
        new_data, backward_results_valid = remove_each_feature (curr_data)
        results_valid = results_valid.append(backward_results_valid)
        curr_data = new_data

    min_mse = results_valid.MSE.idxmin()
    remove_list = (results_valid.loc[:min_mse]).index.values
    final_data = data.copy().drop(remove_list[1:], axis=1)

    return final_data, results_valid