# by Lihi Gur-Arie

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import rdkit
from mpl_toolkits import mplot3d


#####################################################################################


def d2_scatter_plot(xs,ys,color, title, save = False):
    """
    Two dimensional scatter plot
    :param xs: pd.Series
        The date for X axis
    :param ys: pd.Series
        The date for Y axis
    :param color: pd.Series
        The date to be colored by
    :param title: str
        The plot's title
    :param save: bool
        Save the plot
    """

    plt.scatter(x=xs, y=ys, c = color, cmap = 'cool', alpha = 1)                               # Try cmap='GnBu_r'
    plt.title(title)
    plt.xlabel(xs.name)
    plt.ylabel(ys.name)
    plt.colorbar()
    if save is True:
        plt.savefig(f"2D_scatter_plot_{title}.png", bbox_inches='tight', dpi=600)
    plt.show()


def d3_scatter_plot (xs,ys,zs,color, title, save = False):
    """
    Three dimensional scatter plot
    :param xs: pd.Series
        The date for X axis
    :param ys: pd.Series
        The date for Y axis
    :param zs: pd.Series
        The date for Y axis
    :param color: pd.Series
        The date to be colored by
    :param title: str
        The plot's title
    :param save: bool
        Save the plot
    """

    # Creating plot
    fig = plt.figure(figsize = (10, 7))
    ax = plt.axes(projection ="3d")
    p = ax.scatter3D(xs=xs, ys=ys, zs=zs, c=color, cmap='cool', alpha=1)                        # Try cmap='GnBu_r'

    # Change background to white:
    ax.w_xaxis.pane.fill = False
    ax.w_yaxis.pane.fill = False
    ax.w_zaxis.pane.fill = False

    ax.view_init(elev=5., azim=10)

    fig.colorbar(p, ax=ax)


    plt.title(title, fontsize=25, color = 'b')
    ax.set_xlabel(xs.name, fontsize=16)
    ax.set_ylabel(ys.name, fontsize=16)
    ax.set_zlabel(zs.name, fontsize=16)


    # ax.set_xlabel("Feature 1", fontsize=16)
    # ax.set_ylabel("Feature 2", fontsize=16)
    # ax.set_zlabel("Feature 3", fontsize=16)

    # ax.set_xlim3d(-0, 5)
    # ax.set_ylim3d(-0.5, 7.2)
    # ax.set_zlim3d(-0.5, 7.2)

    # Save plot:
    if save is True:
        plt.savefig(f"3D_scatter_plot_{title}.png", bbox_inches='tight', dpi=600)
    plt.show()

def tsne_plot(data, title, perplexity, random_state, n_iter=1000, save = False):
    X = data.iloc[:, :-1]

    # t-SNE algo:
    tsne = TSNE(n_components=2, verbose=1, perplexity=perplexity, random_state=random_state, n_iter=n_iter, n_jobs=-1)
    tsne_results = pd.DataFrame(tsne.fit_transform(X), columns=["tsne1", "tsne2"])


    # plot t-SNE:
    cmap = sns.cubehelix_palette(rot=-.4, as_cmap=True, reverse=True)        # Set the colors
    f, ax = plt.subplots()
    plt.xlabel('t-SNE diamention 1', fontsize=14)
    plt.ylabel('t-SNE diamention 2', fontsize=14)
    ax.axes.xaxis.set_ticks([])                                              # Remove X ticks
    ax.axes.yaxis.set_ticks([])                                              # Remove Y ticks
    points = ax.scatter(tsne_results.iloc[:,0], tsne_results.iloc[:,1], c=data.iloc[:,-1], s=70, cmap=cmap)
    f.colorbar(points)
    plt.title(title, fontsize=20)

    # Save plot:
    if save is True:
        plt.savefig(f"TSNE_plot_{title}_{perplexity}_{random_state}_{n_iter}.png", bbox_inches='tight', dpi=600)
    plt.show()


def correlation_map(data, title, save):
    """
    Plot correlation map
    :param data: pd.DataFrame
        The data for the plot
    :param title: str
        The plot's title
    :param save: bool
        If True, the plot will be saved
    """

    # make a plot of specified dimension (in inches)
    fig, ax = plt.subplots(figsize=(25, 20))
    # pass the axis to draw on
    sns.set(font_scale=2)
    matrix = np.triu(data.corr())
    b = sns.heatmap(data.corr(), annot=False, annot_kws={"size": 15}, fmt='.1g', center=0,
                    cmap=sns.diverging_palette(230, 20, as_cmap=True),  cbar_kws={"shrink": .5}, mask=matrix)
    b.axes.set_title("Correlation Map", fontsize=50)
    b.tick_params(labelsize=15)

    # Save plot:
    if save is True:
        plt.savefig(f"Correlation_map_{title}_.png", bbox_inches='tight', dpi=600)
    plt.show()

def train_vs_test(title,  train_data, test_data, plot_type = "boxplot",save = False):
    """
    Plot train data vs. test data
    :param title: str
        The plot's title
    :param train_data: pd.DataFrame
        The train data
    :param test_data: pd.DataFrame
        The test data
    :param plot_type: str
        'boxplot' or 'swarmplot'
    :param save: bool
        If True, the plot will be saved
    """
    # add y_class category:
    train_data['train_test'] = 1
    test_data ['train_test'] = 0
    all_data = pd.concat([train_data, test_data])
    melted = all_data.melt(id_vars=['train_test'])

    # plot:
    sns.set_style("darkgrid")
    plt.figure(figsize=(25,10))
    plt.title(title, fontsize=30)
    sns.set(font_scale = 1.5,  palette="pastel", color_codes=True)

    if plot_type == 'boxplot':
        ax = sns.boxplot(x="variable", y="value", hue="train_test",data=melted)
    elif plot_type == 'swarmplot':
        ax = sns.swarmplot(x="variable", y="value", hue="train_test", data=melted, dodge=True, size=2)

    ax.set_xticklabels(labels=train_data.columns.values, rotation='vertical', fontsize=15)

    # Add legend:
    handles, _ = ax.get_legend_handles_labels()
    ax.legend(handles, ["Test" ,"Train"])

    plt.xlabel('Features', fontsize=22)
    plt.ylabel('Feature value (standard scaled)', fontsize=22)

    # Save plot:
    if save is True:
        plt.savefig(f"Train_vs_test_plot_{title}_.png", bbox_inches='tight', dpi=600)
    plt.show()
    print ('plot is ready')


def splited_violin_plot(title, x_scaled_standard, y_unscaled, save = False):
    """
    Violin plot of all the features, splited by Y threshold of 13.2
    :param title: str
        The plot's title
    :param x_scaled_standard: pd.DataFrame
        The data after standard scaling
    :param y_unscaled: pd.Series
        The label.
    :param save: bool
        If True, the plot will be saved
    """
    # add y_class category:
    x_scaled_standard['Y_class'] = (np.array([1.0 if y > -13.2 else -1.0 for y in y_unscaled.squeeze()])).reshape(-1, 1)
    melted = x_scaled_standard.melt(id_vars=['Y_class'])

    # plot:
    sns.set_style("darkgrid")
    plt.figure(figsize=(25,7))
    plt.title(title, fontsize=30)

    sns.set(font_scale = 1.5,  palette="pastel", color_codes=True)
    ax = sns.violinplot(x="variable", y="value", hue="Y_class",data=melted,  split=True, bw=.2)
    ax.set_xticklabels(labels=x_scaled_standard.columns.values, rotation='vertical',fontsize=15)

    # Add ledend:
    handles, _ = ax.get_legend_handles_labels()
    ax.legend(handles, ["Score <= -11.25","Score > -13.2" ])
    plt.xlabel('Features', fontsize=22)
    plt.ylabel('Feature value (standard scaled)', fontsize=22)

    # Save plot:
    if save is True:
        plt.savefig(f"Features_violin_plot_{title}_.png", bbox_inches='tight', dpi=600)
    plt.show()
    print ('Violin_plot is ready')

#splited_violin_plot(X_train_standard_scaled)
################################

def data_vs_mol_plots (title, first_data, first_plot_type ="boxplot", second_data = None, second_plot_type ='swarmplot', save = False):
    """
    Plot data vs. specific molecules
    :param title: str
        The plot's title
    :param first_data: pd.DataFrame
        The data after standard scaling
    :param first_plot_type: str
        "boxplot" or "swarmplot"
    :param second_data: pd.DataFrame
        The molecules to examine.
    :param second_plot_type: str
        'stripplot' or 'swarmplot'
    :param save: bool
        If True, the plot will be saved
    """

    # New plot:
    sns.set_style("darkgrid")
    plt.figure(figsize=(25, 7))
    plt.title(title,  fontsize=30)

    # Choose the plot type of the first data_origin:
    if first_plot_type == "swarmplot":
        ax = sns.swarmplot(data=first_data) # color=sns.xkcd_rgb["green blue"])
    else:
        ax = sns.boxplot(data=first_data) # color=sns.xkcd_rgb["green blue"]

    ax.set_xticklabels(labels=first_data.columns.values, rotation='vertical',fontsize=15)

    plt.xlabel('Features', fontsize=22)
    plt.ylabel('Feature value (standard scaled)', fontsize=22)

    # Choose the second plot's type:
    if second_data is not None:
        # Plot the dots:
        second_data['mol_index']= second_data.index.values
        melted = second_data.melt(id_vars=['mol_index'])
        melted.rename(columns={"variable": "Feature", "value": "Feature_value"})

        #melted = melted[melted.mol_index == second_data.index.values[423]]

        if second_plot_type == 'stripplot':
            stp = sns.stripplot(x="variable", y="value", hue='mol_index', data=melted, jitter=True, palette="Set2",
                                linewidth=1, edgecolor='gray')
        else:
            stp = sns.swarmplot(x="variable", y="value", hue='mol_index', data=melted, palette="Set2", linewidth=1, edgecolor='gray', size = 4)

        # Add legend:
        handles, _ = stp.get_legend_handles_labels()
        stp.legend(handles, second_data.index.values)
        plt.xlabel('Features', fontsize=22)
        plt.ylabel('Feature value (standard scaled)', fontsize=22)

    if save == True:
        plt.savefig(f"Features_plot_{title}.png", bbox_inches='tight', dpi=600)
    plt.show()
    print('Plot is ready')

#########################################################################################################33
if __name__ == '__main__':


    # # Load the data_origin (80% train)
    train_data = pd.read_csv(
        r"C:\Users\froma\Desktop\ML\Project Korona\Lihi\model15\program_files\Train_data_m15__13_7_20.csv", index_col=0)
    X_train = train_data.iloc[:, :-1]
    test_data = pd.read_csv(
        r"C:\Users\froma\Desktop\ML\Project Korona\Lihi\model15\program_files\Test_data_m15__13_7_20.csv", index_col=0)
    X_test = test_data.iloc[:, :-1]

    # g = sns.pairplot(train_data,vars=["NHOHCount","VSA_EState4", "VSA_EState8",'RingCount','MaxAbsPartialCharge', 'MinPartialCharge', "VSA_EState9",'FractionCSP3','Num_of_N', "max_affin"])
    # plt.show()

    #box_vs_strip_plots (X_train_standard_scaled, pd.DataFrame(mol_scaled_standard))
    #box_vs_strip_plots (X_train_standard_scaled)
    #box_vs_strip_plots (X_test_standard_scaled)
    #box_vs_strip_plots ("Train_vs_molecules_for_pred", first_data = X_train_standard_scaled, first_plot_type = "boxplot", second_data = X_train_standard_scaled, second_plot_type ='swarmplot', save = False)
    #box_vs_strip_plots ("swarm_plot_Test", first_data = X_test_standard_scaled, first_plot_type = "swarmplot", second_data = None, second_plot_type ='swarmplot', save = True)

    # tsne_plot(data = train_data, title = "Train t-SNE model 15", perplexity=100, random_state=6, n_iter=2000, save = True)

    # # Data scaling:
    # #X_scaled_min_max = (pd.read_csv(r"saved_train_data_scaled_5_7_20.csv", index_col=0)).iloc[:, :-3]
    # std_scalar = StandardScaler().fit(X_train_unscaled)
    # X_train_standard_scaled =pd.DataFrame(std_scalar.transform(X_train_unscaled), index=X_train_unscaled.index, columns=X_train_unscaled.columns)
    # #X_train_standard_scaled ['Y_class'] = (np.array([1.0 if y > -11.25 else -1.0 for y in train_data_unscaled.iloc[:, -1]])).reshape(-1, 1)
    #
    # X_test_standard_scaled =pd.DataFrame(std_scalar.transform(X_test_unscaled), index=X_test_unscaled.index, columns=X_test_unscaled.columns)
    #
    # # Load molecules for pred
    # molecules_for_pred = pd.read_csv(r"Model14/program_files/molecules_for_pred.csv", index_col=0)
    # # Load the chosen features list:
    # features = pd.read_csv(r"Model14/program_files/best_features/Best_features_names_model14_1_7_20.csv", index_col=0)
    # # Take the correct features according to model_14 (52 features):
    # molecules_for_pred = molecules_for_pred[features.iloc[:-1, 0]]
    # molecules_for_pred = molecules_for_pred.iloc[:10]
    # mol_scaled_standard =pd.DataFrame(std_scalar.transform(molecules_for_pred), index=molecules_for_pred.index, columns=molecules_for_pred.columns)
    #
    # predictions= pd.read_csv(r"Model14/program_files/predictions_no_smote_7_7_20.csv", index_col=0)
    # # mol_scaled_standard['Y_class'] = (np.array([1.0 if y > -11.25 else -1.0 for y in predictions.squeeze()])).reshape(-1, 1)

    # ######################################################



    # comparison = pd.DataFrame()
    # comparison['Chi2v'] = X.Chi2v
    # comparison['Chi3v'] = X.Chi3v
    # comparison['Chi2v-Chi3v'] = X.Chi2v - X.Chi3v
    # print(comparison.head(10))

    # d3_scatter_plot (xs=X.NHOHCount, ys=X.Chi3v, zs=X.NumHDonors, color = train_data.max_affin,title = "MolLogP_vs_Chi3v_vs_num_of_N", save = True)