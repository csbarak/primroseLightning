# By Lihi Gur-Arie
# Model30 is a decision tree classifier with binding threshold of -13.2.
# It composed of just 3 features: num_of_N, num_of_C & HelnKierAlpha.
# Model30 predicts binding with 100% accuracy

import os
import numpy as np
import pandas as pd
from pickle import load
import shap
import matplotlib.pyplot as plt
from preproccesing.preproccess import  Mol2MolSupplier, MolFolderSupplier
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from Features_visualization import data_vs_mol_plots
from sklearn.preprocessing import StandardScaler
import os
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Draw, AllChem, Descriptors
import numpy as np
from rdkit.ML.Descriptors import MoleculeDescriptors
from tqdm import tqdm

###################################################
class LGRF30:

    def __init__(self, X_from_RD_features = None, X_from_mol_list=None, X_from_mol2_path=None, y_true = None):
        self.y_true = y_true
        self.X_to_predict = None
        self.dir_path = None
        self.X_train = None

        # if X_from_RD_features and X_from_mol_list:
        #     raise ValueError('Only one of "X_from_RD_features" or "X_from_mol_list" - should have value')
        if X_from_RD_features is not None:
            features_names = pd.read_csv(r"program_files/features_names_m30.csv", index_col=0, header=None)
            self.X_to_predict = X_from_RD_features.copy()[features_names.squeeze()]
        if X_from_mol_list is not None:
            # Convert mol to RDkit features:
            self.X_to_predict = get_features_from_mol_list(X_from_mol_list, names = ['HallKierAlpha'])
        if X_from_mol2_path is not None:
            self.X_to_predict = get_rdkit_features_df(filePath ='data_origin/new_subsets.mol2', names=['HallKierAlpha'])

        self.dir_path = os.path.dirname(os.path.realpath(__file__))+r'/'

    def main(self):
        # Load the chosen features list:
        features = pd.read_csv(self.dir_path+r"program_files\features_names_m30.csv", index_col=0, header = None)

        # Load modal_30 parameters:
        model = load(open(self.dir_path + 'program_files\Saved_model_Model30.sav', 'rb'))  # load the model

        # Predict:
        predictions = pd.DataFrame(model.predict(self.X_to_predict), index=[self.X_to_predict.index.values], columns=['Predicted_score'])

        if self.y_true is None:
            return predictions
        else:
            evaluations = self.evaluate(predictions)
            return predictions, evaluations


    def evaluate(self, pred):

        MSE = mean_squared_error(self.y_true, pred)
        MAE = mean_absolute_error(self.y_true, pred)
        r2 = r2_score(self.y_true, pred)
        results = pd.Series( [MSE, MAE, r2], index=['MSE', 'MAE', 'R2'])
        return results
###############################################################################################################
def number_of_atoms(atom_list, table,  mol, index):
    for i in atom_list:
        table.loc[index, f'num_of_{i}'] = len(mol.GetSubstructMatches(Chem.MolFromSmiles(i)))
        # df['num_of_{}_atoms'.format(i)] = df['mol'].apply(lambda x: len(x.GetSubstructMatches(Chem.MolFromSmiles(i))))

def get_features_from_mol_list(mol_list, names=None ):
    print('get_rdkit_features_df was called')

    table = pd.DataFrame()
    index = 0
    descs = []

    # Run over all molecules, and get the features for each molecule:
    for mol in tqdm (mol_list):
        if mol:
            mol_h = Chem.AddHs(mol)
            table.loc[index, 'Name'] = mol.GetProp('_Name')
            # Get number of C, N atoms:
            number_of_atoms(['C', 'N'], table, mol_h, index)
            # Get the features in the list 'names':
            calc = MoleculeDescriptors.MolecularDescriptorCalculator(names)

            descs.append(calc.CalcDescriptors(mol))
            index = index + 1

    descs = pd.DataFrame(descs, columns=names)

    to_join = [descs]

    result = table.join(to_join)
    result = result.set_index('Name')
    return result

def get_rdkit_features_df(filePath, names=None):

    if filePath.split('.')[-1] == 'sdf':
        database = Chem.SDMolSupplier(filePath,sanitize=True)
    else:
        database = Mol2MolSupplier(filePath,sanitize=True)

    result = get_features_from_mol_list(database, names=names)

    return result

###############################################################################################################


mol2_org = get_rdkit_features_df(filePath=r'\Data\aligned.mol2', names=['HallKierAlpha'])
predictions_org = LGRF30(X_from_RD_features = mol2_org, y_true=None).main()



