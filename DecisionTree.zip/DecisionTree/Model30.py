# by Lihi Gur-Arie
# This is a tree classifier model, with binding threshold = 1.
# In this model i will look for all the 3-features combinations that give f1_score = 1.
# The parameters are max_depth = 3, and i run over all the 80% training group without Cross Validation (It takes a lot of time).
# The results are on the training, so i will validate them on the test data.


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sys


from Feature_reduction import  backward_features_reduction,remove_features_by_name, reduce_features_by_lasso_coefficient, Remove_features_by_correlation

from Decision_Tree_Classifier import Trees_Clasiffier, Remove_features_by_Forward_feature_addition_Tree
from Features_visualization import data_vs_mol_plots, splited_violin_plot, train_vs_test, correlation_map, d3_scatter_plot, d2_scatter_plot
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.tree import DecisionTreeClassifier
from termcolor import colored
from sklearn.metrics import roc_curve, precision_recall_curve, auc, make_scorer, recall_score, accuracy_score, precision_score, confusion_matrix, classification_report, f1_score
import matplotlib.pyplot as plt
from tqdm import tqdm

path=r"\program_files"
# Open Class Data :
X_train_original = pd.read_csv(path + "\X_Train_13.2_threshold.csv", index_col=0)
y_train_original = pd.read_csv(path + r"\Y_Train_stratified_treshold_13_2.csv", index_col=0, header=None)
X_test_original = pd.read_csv(path + r"\X_Test_data_13.2_threshold.csv", index_col=0)
y_test_original = pd.read_csv(path + r"\Y_Test_stratified_treshold_13_2.csv", index_col=0, header=None)
#
# ##################################################################################3
X_train_original['Y'] = y_train_original

# Remove features with low correlation to y:
# remove features with variance=0
X_train_r1 = Remove_features_by_correlation(data = X_train_original).main(var_threshold=0, y_cor_threshold=0, x_cor_threshold=1)
X_train_r1 = X_train_r1.iloc[:,:-1]

# Run decision Tree classifier over all the 3-features combinations
results_table_valid = pd.DataFrame()
for first in range (X_train_r1.shape[1]-2):
    print(f'First feature = {first}')
    if first != 0:
        results_table_valid = results_table_valid.sort_values(by = ['f1_score'], ascending=False)
        results_table_valid.to_csv(f'{first}_results_temp.csv')

    for second in range (first + 1, X_train_r1.shape[1]-1):
        print(f'{second}')
        for third in range (second + 1, X_train_r1.shape[1]):

            results = Trees_Clasiffier(X_train=X_train_r1.iloc[:, [first, second, third]], Y_train=y_train_original, X_test=X_train_r1.iloc[:, [first, second, third]], Y_test=y_train_original, verbose=0).main(cv=3, max_depth=3)
            results['Feature1'] = X_train_r1.columns.values[first]
            results['Feature2'] = X_train_r1.columns.values[second]
            results['Feature3'] = X_train_r1.columns.values[third]

            results_table_valid = results_table_valid.append(pd.DataFrame(results).T)

# results_table_valid.to_csv(r'final_3_features_combination_1cv_results_table_train.csv')
print('Finished')
print('Finished')

# Get the test results of the combinations that got f1_score = 1 on the train
# results_table = pd.read_csv(r"final_3_features_combination_1cv_results_table_train1.csv", index_col=0)
# best_3_comb_features = results_table.loc[results_table['f1_score'] == 1]
#
# results_table = pd.DataFrame()
#
# for i in range (best_3_comb_features.shape[0]):
#     comb = best_3_comb_features.iloc[i,:]
#     results = Trees_Clasiffier(X_train=X_train_r1.loc[:, [comb.iloc[-3], comb.iloc[-2], comb.iloc[-1]]], Y_train=y_train_original,
#                                X_test=X_test_original.loc[:, [comb.iloc[-3], comb.iloc[-2], comb.iloc[-1]]], Y_test=y_test_original,
#                                verbose=0).main(cv=10, max_depth=3)
#     results['Feature1'] = comb.iloc[-3]
#     results['Feature2'] = comb.iloc[-2]
#     results['Feature3'] = comb.iloc[-1]
#
#     results_table = results_table.append(pd.DataFrame(results).T)
#results_table_valid.to_csv(r'results_Test.csv')

#######################################################################
# Get the 10kcv results of the combinations that got f1_score = 1 on the train

# best_3_comb_features_cv = results_table.loc[results_table['f1_score_valid'] == 1]
# results_table = pd.DataFrame()
#
# for i in range (best_3_comb_features_cv.shape[0]):
#     comb = best_3_comb_features_cv.iloc[i,:]
#     results = Trees_Clasiffier(X_train=X_train_r1.loc[:, [comb.iloc[-3], comb.iloc[-2], comb.iloc[-1]]], Y_train=y_train_original,
#                                verbose=0).main(cv=10, max_depth=3)
#     results['Feature1'] = comb.iloc[-3]
#     results['Feature2'] = comb.iloc[-2]
#     results['Feature3'] = comb.iloc[-1]
#
#     results_table= results_table.append(pd.DataFrame(results).T)
#results_table_valid.to_csv(r'results_Train_data_10kCV.csv')


#####################################################################################3

#perfect_features_comb = results_table[results_table['f1_score_valid'] == 1]

# results = Trees_Clasiffier(X_train=X_train_r1.loc[:, [perfect_features_comb.iloc[0,-3], perfect_features_comb.iloc[0,-2], perfect_features_comb.iloc[0,-1]]],
#                            Y_train=y_train_original,
#                            X_test=X_test_original.loc[:, [perfect_features_comb.iloc[0,-3], perfect_features_comb.iloc[0,-2], perfect_features_comb.iloc[0,-1]]],
#                            Y_test=y_test_original, verbose=1).main(cv=10, max_depth=3, show_plots=False, save_plots=False)

# results = Trees_Clasiffier(X_train=X_train_r1.loc[:, [perfect_features_comb.iloc[1,-3], perfect_features_comb.iloc[1,-2], perfect_features_comb.iloc[1,-1]]],
#                            Y_train=y_train_original,X_test=X_test_original.loc[:, [perfect_features_comb.iloc[1,-3], perfect_features_comb.iloc[1,-2], perfect_features_comb.iloc[1,-1]]],
#                            Y_test=y_test_original, verbose=1).main(cv=10, max_depth=3, show_plots=False, save_plots=False)
#
# results = Trees_Clasiffier(X_train=X_train_r1.loc[:, [perfect_features_comb.iloc[2,-3], perfect_features_comb.iloc[2,-2], perfect_features_comb.iloc[2,-1]]],
#                            Y_train=y_train_original,X_test=X_test_original.loc[:, [perfect_features_comb.iloc[2,-3], perfect_features_comb.iloc[2,-2], perfect_features_comb.iloc[2,-1]]],
#                            Y_test=y_test_original, verbose=1).main(cv=10, max_depth=3, show_plots=False, save_plots=False)
#
# results = Trees_Clasiffier(X_train=X_train_r1.loc[:, [perfect_features_comb.iloc[3,-3], perfect_features_comb.iloc[3,-2], perfect_features_comb.iloc[3,-1]]],
#                            Y_train=y_train_original,X_test=X_test_original.loc[:, [perfect_features_comb.iloc[3,-3], perfect_features_comb.iloc[3,-2], perfect_features_comb.iloc[3,-1]]],
#                            Y_test=y_test_original, verbose=1).main(cv=10, max_depth=3, show_plots=False, save_plots=False)

# X_Train_1__C_N_HKA  = X_train_r1.loc[:, [perfect_features_comb.iloc[0, -3], perfect_features_comb.iloc[0, -2], perfect_features_comb.iloc[0, -1]]]
# X_Train_1__C_N_HKA.to_csv(r'X_Train1__C_N_HKA.csv')
#
# X_Train_2__N_HKA_CSP3 = X_train_r1.loc[:, [perfect_features_comb.iloc[1,-3], perfect_features_comb.iloc[1,-2], perfect_features_comb.iloc[1,-1]]]
# X_Train_2__N_HKA_CSP3.to_csv(r'X_Train2__N_HKA_CSP3.csv')
#
# X_Train_3__N_VSA8_CSP3 = X_train_r1.loc[:, [perfect_features_comb.iloc[2,-3], perfect_features_comb.iloc[2,-2], perfect_features_comb.iloc[2,-1]]]
# X_Train_3__N_VSA8_CSP3.to_csv(r'X_Train3__N_VSA8_CSP3.csv')
#
# X_Train_4___SMRVSA3_SMRVSA6_quantN = X_train_r1.loc[:, [perfect_features_comb.iloc[3,-3], perfect_features_comb.iloc[3,-2], perfect_features_comb.iloc[3,-1]]]
# X_Train_4___SMRVSA3_SMRVSA6_quantN.to_csv(r'X_Train4__SMRVSA3_SMRVSA6_quantN.csv')


# d3_scatter_plot (xs=X_Train_1__C_N_HKA.num_of_N, ys=X_Train_1__C_N_HKA.num_of_C,zs=X_Train_1__C_N_HKA.HallKierAlpha,color=y_train_original, title='model28_All_data_1', save = False)
#
# print('y')

##################################################################3
# Open data:
X_Train_m30 = pd.read_csv(r"program_files/X_Train1__C_N_HKA.csv", index_col=0)
Y_Train_m30 = pd.read_csv(r"program_files/Y_Train_stratified_treshold_13_2.csv", index_col=0, header=None)
X_Test_m30 = pd.read_csv(r"program_files/X_Test_data_13.2_threshold.csv", index_col=0)
Y_test_m30 = pd.read_csv(r"program_files/Y_Test_stratified_treshold_13_2.csv", index_col=0, header=None)
features_names = pd.read_csv(r"program_files/features_names_m30.csv", index_col=0, header=None)
X_Test_m30 = X_Test_m30[features_names.squeeze()]

m30 = Trees_Clasiffier(X_train=X_Train_m30, Y_train=Y_Train_m30,X_test=X_Test_m30, Y_test=Y_test_m30, verbose=0)
results = m30.main(cv=10, max_depth=3)
# m30.save_model('Model30')






